#!/bin/bash

# Script de diagnostic VPN WireGuard
# Usage: ./test-vpn.sh

echo "🔍 Diagnostic VPN WireGuard"
echo "=========================================="
echo ""

# Couleurs
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

success() {
    echo -e "${GREEN}✓${NC} $1"
}

error() {
    echo -e "${RED}✗${NC} $1"
}

warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

info() {
    echo -e "${BLUE}ℹ${NC} $1"
}

# Test 1: WireGuard installé
echo "Test 1: Installation WireGuard"
if command -v wg &> /dev/null; then
    success "WireGuard est installé"
else
    error "WireGuard n'est pas installé"
    exit 1
fi

# Test 2: Service actif
echo "Test 2: Service WireGuard"
if systemctl is-active --quiet wg-quick@wg0; then
    success "Service wg-quick@wg0 actif"
else
    error "Service wg-quick@wg0 inactif"
    warning "Essayez: systemctl start wg-quick@wg0"
    exit 1
fi

# Test 3: Interface réseau
echo "Test 3: Interface réseau wg0"
if ip link show wg0 &> /dev/null; then
    success "Interface wg0 présente"
    IP=$(ip addr show wg0 | grep "inet " | awk '{print $2}')
    info "   IP serveur: $IP"
else
    error "Interface wg0 absente"
    exit 1
fi

# Test 4: Fichiers de configuration
echo "Test 4: Fichiers de configuration"
if [ -f /etc/wireguard/wg0.conf ]; then
    success "Config serveur présente"
else
    error "Config serveur absente"
    exit 1
fi

if [ -f /etc/wireguard/server_public.key ]; then
    success "Clé publique serveur présente"
    SERVER_KEY=$(cat /etc/wireguard/server_public.key)
    info "   Clé: $SERVER_KEY"
else
    error "Clé publique serveur absente"
fi

# Test 5: Nombre de clients
echo "Test 5: Clients configurés"
CLIENT_COUNT=$(grep -c "^# " /etc/wireguard/wg0.conf | grep -v "^#" || echo 0)
if [ "$CLIENT_COUNT" -gt 0 ]; then
    success "$CLIENT_COUNT client(s) configuré(s)"
    echo ""
    echo "   Clients :"
    grep "^# " /etc/wireguard/wg0.conf | grep -v "^#" | sed 's/^#/      -/'
else
    warning "Aucun client configuré"
    info "   Créez un client: add-vpn-client.sh <nom>"
fi

# Test 6: Clients connectés
echo "Test 6: Clients connectés"
CONNECTED=$(wg show wg0 peers 2>/dev/null | wc -l)
if [ "$CONNECTED" -gt 0 ]; then
    success "$CONNECTED client(s) connecté(s)"
    echo ""
    wg show wg0 | grep -A 4 "peer:"
else
    info "Aucun client connecté actuellement"
fi

# Test 7: Firewall UFW
echo "Test 7: Règles firewall"
if command -v ufw &> /dev/null; then
    if ufw status | grep -q "51820.*ALLOW"; then
        success "Port WireGuard 51820/UDP ouvert"
    else
        error "Port WireGuard 51820/UDP non ouvert"
        warning "Exécutez: ufw allow 51820/udp"
    fi
    
    if ufw status | grep -q "10.8.0.0/24"; then
        success "Règles VPN présentes"
        VPN_RULES=$(ufw status | grep "10.8.0.0/24" | wc -l)
        info "   $VPN_RULES règle(s) VPN configurée(s)"
    else
        warning "Aucune règle spécifique VPN trouvée"
    fi
else
    warning "UFW non installé"
fi

# Test 8: Forwarding IP
echo "Test 8: IP Forwarding"
if [ "$(cat /proc/sys/net/ipv4/ip_forward)" = "1" ]; then
    success "IP Forwarding activé"
else
    error "IP Forwarding désactivé"
    warning "Activez-le: sysctl -w net.ipv4.ip_forward=1"
fi

# Test 9: Nginx (interface admin)
echo "Test 9: Interface web admin"
if systemctl is-active --quiet nginx; then
    success "Nginx actif"
    
    if [ -d /var/www/vpn-admin ]; then
        success "Répertoire admin présent"
        
        if [ -f /etc/nginx/sites-enabled/vpn-admin ]; then
            success "Site Nginx activé"
            PORT=$(grep "listen" /etc/nginx/sites-available/vpn-admin | head -1 | awk '{print $2}' | tr -d ';')
            info "   Port: $PORT"
            info "   URL: http://10.8.0.1:$PORT"
        else
            warning "Site Nginx non activé"
        fi
    else
        warning "Répertoire admin absent"
    fi
else
    warning "Nginx non actif (interface admin indisponible)"
fi

# Test 10: Scripts de gestion
echo "Test 10: Scripts de gestion"
if [ -f /usr/local/bin/add-vpn-client.sh ]; then
    success "Script add-vpn-client.sh présent"
else
    error "Script add-vpn-client.sh absent"
fi

if [ -f /usr/local/bin/remove-vpn-client.sh ]; then
    success "Script remove-vpn-client.sh présent"
else
    error "Script remove-vpn-client.sh absent"
fi

# Résumé
echo ""
echo "=========================================="
echo "📊 RÉSUMÉ"
echo "=========================================="
echo ""

# IP publique
PUBLIC_IP=$(curl -s ifconfig.me)
info "IP publique du serveur: $PUBLIC_IP"

# Réseau VPN
info "Réseau VPN: 10.8.0.0/24"

# Port
info "Port WireGuard: 51820/UDP"

# Clients
info "Clients configurés: $CLIENT_COUNT"
info "Clients connectés: $CONNECTED"

echo ""
echo "=========================================="
echo "📝 PROCHAINES ÉTAPES"
echo "=========================================="
echo ""

if [ "$CLIENT_COUNT" -eq 0 ]; then
    echo "1. Créer votre premier client:"
    echo "   add-vpn-client.sh bertrand"
    echo ""
    echo "2. Récupérer la configuration:"
    echo "   cat /etc/wireguard/clients/bertrand.conf"
    echo ""
fi

if [ "$CONNECTED" -eq 0 ]; then
    echo "3. Se connecter au VPN depuis votre appareil"
    echo ""
fi

echo "4. Accéder à l'interface admin:"
echo "   http://10.8.0.1:8888"
echo ""
echo "5. Voir les connexions actives:"
echo "   wg show"
echo ""

echo "=========================================="
echo ""
