#!/bin/bash

echo "🚀 Installation complète de WireGuard VPN avec interface admin"
echo "=============================================================="
echo ""

# Variables
VPS_IP="137.74.12.199"
ADMIN_DIR="/var/www/vpn-admin"
NGINX_CONF="/etc/nginx/sites-available/vpn-admin"

# Couleurs
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}📦 Étape 1/5 : Installation des dépendances${NC}"
apt update
apt install -y wireguard qrencode iptables nginx php-fpm

echo ""
echo -e "${BLUE}🔑 Étape 2/5 : Configuration de WireGuard${NC}"

# Activation du forwarding IP
if ! grep -q "net.ipv4.ip_forward=1" /etc/sysctl.conf; then
    echo "net.ipv4.ip_forward=1" >> /etc/sysctl.conf
    sysctl -p
fi

# Création des répertoires
mkdir -p /etc/wireguard/clients
cd /etc/wireguard
umask 077

# Génération des clés serveur si elles n'existent pas
if [ ! -f server_private.key ]; then
    wg genkey | tee server_private.key | wg pubkey > server_public.key
fi

SERVER_PRIVATE=$(cat server_private.key)
SERVER_PUBLIC=$(cat server_public.key)
SERVER_IP=$(curl -s ifconfig.me || echo $VPS_IP)

# Création de la config serveur
cat > /etc/wireguard/wg0.conf << EOL
[Interface]
Address = 10.8.0.1/24
ListenPort = 51820
PrivateKey = $SERVER_PRIVATE
PostUp = iptables -A FORWARD -i wg0 -j ACCEPT; iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE
PostDown = iptables -D FORWARD -i wg0 -j ACCEPT; iptables -t nat -D POSTROUTING -o eth0 -j MASQUERADE

# Les clients seront ajoutés automatiquement ci-dessous
EOL

chmod 600 /etc/wireguard/wg0.conf

echo ""
echo -e "${BLUE}🔥 Étape 3/5 : Configuration du firewall${NC}"

# Autoriser WireGuard depuis Internet
ufw allow 51820/udp comment 'WireGuard VPN'

# Exemples de ports à autoriser UNIQUEMENT via VPN
# Adaptez selon vos besoins !
declare -a VPN_PORTS=(
    "5678:n8n"
    "3000:Open WebUI"
    "10000:Webmin"
    "8080:Services internes"
)

for port_desc in "${VPN_PORTS[@]}"; do
    port=$(echo $port_desc | cut -d':' -f1)
    desc=$(echo $port_desc | cut -d':' -f2)
    ufw allow from 10.8.0.0/24 to any port $port comment "$desc via VPN"
    echo "  ✓ Port $port ($desc) accessible uniquement via VPN"
done

ufw --force enable
ufw reload

echo ""
echo -e "${BLUE}📝 Étape 4/5 : Installation des scripts de gestion${NC}"

# Script d'ajout de clients
cat > /usr/local/bin/add-vpn-client.sh << 'EOFSCRIPT'
#!/bin/bash
if [ -z "$1" ]; then
    echo "Usage: $0 <client_name>"
    exit 1
fi

CLIENT_NAME=$1
WG_DIR="/etc/wireguard"
CLIENT_DIR="/etc/wireguard/clients"
mkdir -p $CLIENT_DIR

# Trouver la prochaine IP disponible
LAST_IP=$(grep "AllowedIPs" $WG_DIR/wg0.conf | tail -1 | cut -d '=' -f2 | cut -d '/' -f1 | awk '{print $1}' | cut -d '.' -f4)
if [ -z "$LAST_IP" ] || [ "$LAST_IP" = "" ]; then
    CLIENT_IP="10.8.0.2"
else
    CLIENT_IP="10.8.0.$((LAST_IP + 1))"
fi

# Vérifier si le client existe déjà
if grep -q "# $CLIENT_NAME" $WG_DIR/wg0.conf; then
    echo "❌ Le client $CLIENT_NAME existe déjà"
    exit 1
fi

cd $CLIENT_DIR
umask 077
wg genkey | tee ${CLIENT_NAME}_private.key | wg pubkey > ${CLIENT_NAME}_public.key

CLIENT_PRIVATE=$(cat ${CLIENT_NAME}_private.key)
CLIENT_PUBLIC=$(cat ${CLIENT_NAME}_public.key)
SERVER_PUBLIC=$(cat $WG_DIR/server_public.key)
SERVER_IP=$(curl -s ifconfig.me)

# Ajouter le client au serveur
cat >> $WG_DIR/wg0.conf << EOL

[Peer]
# $CLIENT_NAME
PublicKey = $CLIENT_PUBLIC
AllowedIPs = $CLIENT_IP/32
EOL

# Créer la config client
cat > $CLIENT_DIR/${CLIENT_NAME}.conf << EOL
[Interface]
PrivateKey = $CLIENT_PRIVATE
Address = $CLIENT_IP/24
DNS = 1.1.1.1, 8.8.8.8

[Peer]
PublicKey = $SERVER_PUBLIC
Endpoint = $SERVER_IP:51820
AllowedIPs = 10.8.0.0/24, $SERVER_IP/32
PersistentKeepalive = 25
EOL

chmod 600 $CLIENT_DIR/${CLIENT_NAME}.conf
wg syncconf wg0 <(wg-quick strip wg0)

echo "✅ Client $CLIENT_NAME créé avec IP $CLIENT_IP"
EOFSCRIPT

# Script de suppression
cat > /usr/local/bin/remove-vpn-client.sh << 'EOFSCRIPT'
#!/bin/bash
if [ -z "$1" ]; then
    echo "Usage: $0 <client_name>"
    exit 1
fi

CLIENT_NAME=$1
WG_DIR="/etc/wireguard"
CLIENT_DIR="/etc/wireguard/clients"

if ! grep -q "# $CLIENT_NAME" $WG_DIR/wg0.conf; then
    echo "❌ Le client $CLIENT_NAME n'existe pas"
    exit 1
fi

sed -i "/# $CLIENT_NAME/,/^$/d" $WG_DIR/wg0.conf
rm -f $CLIENT_DIR/${CLIENT_NAME}_private.key
rm -f $CLIENT_DIR/${CLIENT_NAME}_public.key
rm -f $CLIENT_DIR/${CLIENT_NAME}.conf

wg syncconf wg0 <(wg-quick strip wg0)
echo "✅ Client $CLIENT_NAME supprimé"
EOFSCRIPT

chmod +x /usr/local/bin/add-vpn-client.sh
chmod +x /usr/local/bin/remove-vpn-client.sh

# Démarrage de WireGuard
systemctl enable wg-quick@wg0
systemctl start wg-quick@wg0

echo ""
echo -e "${BLUE}🌐 Étape 5/5 : Installation de l'interface web${NC}"

# Créer le répertoire web
mkdir -p $ADMIN_DIR
cp -r /home/claude/vpn-admin/* $ADMIN_DIR/
chown -R www-data:www-data $ADMIN_DIR

# Configurer Nginx
cat > $NGINX_CONF << 'EOFNGINX'
server {
    listen 8888;
    server_name _;
    
    root /var/www/vpn-admin;
    index index.php;
    
    # Sécurité : accessible uniquement depuis VPN
    allow 10.8.0.0/24;
    deny all;
    
    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }
    
    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/var/run/php/php-fpm.sock;
    }
    
    location ~ /\.ht {
        deny all;
    }
}
EOFNGINX

# Activer le site
ln -sf $NGINX_CONF /etc/nginx/sites-enabled/vpn-admin
nginx -t && systemctl reload nginx

echo ""
echo -e "${GREEN}✅ Installation terminée !${NC}"
echo ""
echo "=============================================================="
echo -e "${GREEN}🎉 Votre VPN WireGuard est opérationnel !${NC}"
echo "=============================================================="
echo ""
echo "📊 Informations :"
echo "   • IP publique : $SERVER_IP"
echo "   • Réseau VPN : 10.8.0.0/24"
echo "   • Port WireGuard : 51820/UDP"
echo ""
echo "🌐 Interface d'administration :"
echo "   • URL : http://10.8.0.1:8888 (accessible UNIQUEMENT via VPN)"
echo "   • Mot de passe : ChangeMe2024! (À CHANGER dans index.php !)"
echo ""
echo "🔧 Commandes utiles :"
echo "   • Créer un client : add-vpn-client.sh <nom>"
echo "   • Supprimer un client : remove-vpn-client.sh <nom>"
echo "   • Voir les connexions : wg show"
echo "   • Statut WireGuard : systemctl status wg-quick@wg0"
echo ""
echo "⚠️  IMPORTANT :"
echo "   1. Créez votre premier client VPN : add-vpn-client.sh bertrand"
echo "   2. Téléchargez la config : /etc/wireguard/clients/bertrand.conf"
echo "   3. Connectez-vous au VPN"
echo "   4. Accédez à l'interface admin : http://10.8.0.1:8888"
echo "   5. CHANGEZ le mot de passe admin dans /var/www/vpn-admin/index.php"
echo ""
echo -e "${BLUE}🔐 Clé publique du serveur :${NC}"
echo "$SERVER_PUBLIC"
echo ""
