#!/bin/bash

# Script de sauvegarde de la configuration WireGuard
# Usage: ./backup-vpn.sh [destination]
# Par défaut : /root/vpn-backups/

BACKUP_DIR="${1:-/root/vpn-backups}"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_NAME="wireguard_backup_${TIMESTAMP}.tar.gz"
BACKUP_PATH="${BACKUP_DIR}/${BACKUP_NAME}"

# Couleurs
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${BLUE}🔒 Sauvegarde de la configuration WireGuard${NC}"
echo "=================================================="
echo ""

# Créer le répertoire de sauvegarde
mkdir -p "$BACKUP_DIR"

echo "📁 Répertoire de sauvegarde : $BACKUP_DIR"
echo "📦 Nom du fichier : $BACKUP_NAME"
echo ""

# Liste des éléments à sauvegarder
ITEMS_TO_BACKUP=(
    "/etc/wireguard/wg0.conf"
    "/etc/wireguard/server_private.key"
    "/etc/wireguard/server_public.key"
    "/etc/wireguard/clients/"
    "/var/www/vpn-admin/"
    "/usr/local/bin/add-vpn-client.sh"
    "/usr/local/bin/remove-vpn-client.sh"
)

echo "📋 Éléments à sauvegarder :"
for item in "${ITEMS_TO_BACKUP[@]}"; do
    if [ -e "$item" ]; then
        echo "   ✓ $item"
    else
        echo "   ⚠ $item (non trouvé)"
    fi
done
echo ""

# Créer l'archive
echo "🗜️  Création de l'archive..."
tar -czf "$BACKUP_PATH" \
    --ignore-failed-read \
    "${ITEMS_TO_BACKUP[@]}" \
    2>/dev/null

if [ $? -eq 0 ]; then
    BACKUP_SIZE=$(du -h "$BACKUP_PATH" | cut -f1)
    echo -e "${GREEN}✅ Sauvegarde créée avec succès !${NC}"
    echo ""
    echo "📊 Informations :"
    echo "   • Fichier : $BACKUP_PATH"
    echo "   • Taille : $BACKUP_SIZE"
    echo "   • Date : $(date '+%Y-%m-%d %H:%M:%S')"
    echo ""
    
    # Lister les 5 dernières sauvegardes
    echo "📚 Dernières sauvegardes :"
    ls -lht "$BACKUP_DIR" | grep "wireguard_backup" | head -5 | awk '{printf "   • %s %s (%s)\n", $9, $6" "$7, $5}'
    echo ""
    
    # Nettoyage des anciennes sauvegardes (garder les 10 dernières)
    BACKUP_COUNT=$(ls -1 "$BACKUP_DIR"/wireguard_backup_*.tar.gz 2>/dev/null | wc -l)
    if [ "$BACKUP_COUNT" -gt 10 ]; then
        echo -e "${YELLOW}🧹 Nettoyage des anciennes sauvegardes...${NC}"
        ls -t "$BACKUP_DIR"/wireguard_backup_*.tar.gz | tail -n +11 | xargs rm -f
        echo "   Conservées : 10 sauvegardes les plus récentes"
        echo ""
    fi
    
    # Instructions de restauration
    echo "📖 Pour restaurer cette sauvegarde :"
    echo "   tar -xzf $BACKUP_PATH -C /"
    echo "   systemctl restart wg-quick@wg0"
    echo "   systemctl restart nginx"
    echo ""
    
    exit 0
else
    echo -e "${RED}❌ Erreur lors de la création de la sauvegarde${NC}"
    exit 1
fi
