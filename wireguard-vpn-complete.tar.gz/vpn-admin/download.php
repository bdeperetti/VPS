<?php
session_start();

if (!isset($_SESSION['authenticated'])) {
    header('Location: index.php');
    exit;
}

$clientName = $_GET['client'] ?? '';
$clientName = preg_replace('/[^a-zA-Z0-9_-]/', '', $clientName);

if (empty($clientName)) {
    die('Nom de client invalide');
}

$configFile = "/etc/wireguard/clients/{$clientName}.conf";

if (!file_exists($configFile)) {
    die('Configuration introuvable');
}

header('Content-Type: text/plain');
header('Content-Disposition: attachment; filename="' . $clientName . '.conf"');
header('Content-Length: ' . filesize($configFile));

readfile($configFile);
