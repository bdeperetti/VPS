<?php
session_start();

// Configuration
define('ADMIN_PASSWORD', password_hash('ChangeMe2024!', PASSWORD_DEFAULT)); // À CHANGER !
define('WG_DIR', '/etc/wireguard');
define('CLIENT_DIR', '/etc/wireguard/clients');

// Authentification
if (!isset($_SESSION['authenticated'])) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['password'])) {
        if (password_verify($_POST['password'], ADMIN_PASSWORD)) {
            $_SESSION['authenticated'] = true;
            header('Location: index.php');
            exit;
        } else {
            $error = 'Mot de passe incorrect';
        }
    }
    
    // Page de login
    ?>
    <!DOCTYPE html>
    <html lang="fr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>VPN Admin - Connexion</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body {
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            .login-box {
                background: white;
                padding: 2.5rem;
                border-radius: 12px;
                box-shadow: 0 20px 60px rgba(0,0,0,0.3);
                width: 100%;
                max-width: 400px;
            }
            h1 {
                color: #667eea;
                margin-bottom: 0.5rem;
                font-size: 1.8rem;
            }
            .subtitle {
                color: #666;
                margin-bottom: 2rem;
                font-size: 0.9rem;
            }
            input[type="password"] {
                width: 100%;
                padding: 0.875rem;
                border: 2px solid #e2e8f0;
                border-radius: 8px;
                font-size: 1rem;
                transition: all 0.2s;
            }
            input[type="password"]:focus {
                outline: none;
                border-color: #667eea;
                box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
            }
            button {
                width: 100%;
                padding: 0.875rem;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                border: none;
                border-radius: 8px;
                font-size: 1rem;
                font-weight: 600;
                cursor: pointer;
                margin-top: 1rem;
                transition: transform 0.2s, box-shadow 0.2s;
            }
            button:hover {
                transform: translateY(-2px);
                box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4);
            }
            .error {
                background: #fee;
                color: #c33;
                padding: 0.75rem;
                border-radius: 8px;
                margin-bottom: 1rem;
                font-size: 0.9rem;
            }
        </style>
    </head>
    <body>
        <div class="login-box">
            <h1>🔒 VPN Admin</h1>
            <p class="subtitle">Gestion WireGuard - kair.fr</p>
            <?php if (isset($error)): ?>
                <div class="error"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <form method="POST">
                <input type="password" name="password" placeholder="Mot de passe admin" required autofocus>
                <button type="submit">Se connecter</button>
            </form>
        </div>
    </body>
    </html>
    <?php
    exit;
}

// Déconnexion
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: index.php');
    exit;
}

// Actions
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add_client':
                $clientName = preg_replace('/[^a-zA-Z0-9_-]/', '', $_POST['client_name']);
                if (!empty($clientName)) {
                    exec("bash /usr/local/bin/add-vpn-client.sh " . escapeshellarg($clientName) . " 2>&1", $output, $return);
                    if ($return === 0) {
                        $message = "Client $clientName créé avec succès";
                        $messageType = 'success';
                    } else {
                        $message = "Erreur : " . implode("\n", $output);
                        $messageType = 'error';
                    }
                }
                break;
                
            case 'remove_client':
                $clientName = $_POST['client_name'];
                exec("bash /usr/local/bin/remove-vpn-client.sh " . escapeshellarg($clientName) . " 2>&1", $output, $return);
                if ($return === 0) {
                    $message = "Client $clientName supprimé";
                    $messageType = 'success';
                } else {
                    $message = "Erreur : " . implode("\n", $output);
                    $messageType = 'error';
                }
                break;
        }
    }
}

// Récupérer la liste des clients
function getClients() {
    $clients = [];
    $config = file_get_contents(WG_DIR . '/wg0.conf');
    preg_match_all('/# (.+?)\nPublicKey = (.+?)\nAllowedIPs = (.+?)\/32/s', $config, $matches, PREG_SET_ORDER);
    
    foreach ($matches as $match) {
        $clients[] = [
            'name' => trim($match[1]),
            'pubkey' => trim($match[2]),
            'ip' => trim($match[3])
        ];
    }
    return $clients;
}

// Récupérer les clients connectés
function getConnectedClients() {
    exec('wg show wg0 2>&1', $output);
    $connected = [];
    $currentPeer = null;
    
    foreach ($output as $line) {
        if (strpos($line, 'peer:') === 0) {
            $currentPeer = trim(str_replace('peer:', '', $line));
        }
        if ($currentPeer && strpos($line, 'endpoint:') !== false) {
            $connected[$currentPeer] = trim(str_replace('endpoint:', '', $line));
        }
    }
    return $connected;
}

$clients = getClients();
$connected = getConnectedClients();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VPN Admin - Dashboard</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif;
            background: #f7fafc;
            color: #2d3748;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1.5rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .header h1 { font-size: 1.5rem; }
        .header a {
            color: white;
            text-decoration: none;
            padding: 0.5rem 1rem;
            background: rgba(255,255,255,0.2);
            border-radius: 6px;
            font-size: 0.9rem;
            transition: background 0.2s;
        }
        .header a:hover { background: rgba(255,255,255,0.3); }
        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 2rem;
        }
        .card {
            background: white;
            border-radius: 12px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }
        .card h2 {
            color: #667eea;
            margin-bottom: 1.5rem;
            font-size: 1.3rem;
        }
        .message {
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            font-weight: 500;
        }
        .message.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .message.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .form-group {
            margin-bottom: 1.5rem;
        }
        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: #4a5568;
        }
        input[type="text"] {
            width: 100%;
            padding: 0.75rem;
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            font-size: 1rem;
            transition: border-color 0.2s;
        }
        input[type="text"]:focus {
            outline: none;
            border-color: #667eea;
        }
        .btn {
            padding: 0.75rem 1.5rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
        }
        .btn-danger {
            background: linear-gradient(135deg, #f56565 0%, #c53030 100%);
        }
        .btn-secondary {
            background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
            font-size: 0.875rem;
            padding: 0.5rem 1rem;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid #e2e8f0;
        }
        th {
            background: #f7fafc;
            font-weight: 600;
            color: #4a5568;
        }
        tr:hover {
            background: #f7fafc;
        }
        .badge {
            display: inline-block;
            padding: 0.25rem 0.75rem;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        .badge-success {
            background: #d4edda;
            color: #155724;
        }
        .badge-secondary {
            background: #e2e8f0;
            color: #718096;
        }
        .actions {
            display: flex;
            gap: 0.5rem;
        }
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        .stat-card {
            background: white;
            padding: 1.5rem;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            border-left: 4px solid #667eea;
        }
        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            color: #667eea;
            margin-bottom: 0.25rem;
        }
        .stat-label {
            color: #718096;
            font-size: 0.875rem;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>🔐 VPN Admin - WireGuard</h1>
        <a href="?logout">Déconnexion</a>
    </div>
    
    <div class="container">
        <?php if ($message): ?>
            <div class="message <?= $messageType ?>"><?= nl2br(htmlspecialchars($message)) ?></div>
        <?php endif; ?>
        
        <div class="stats">
            <div class="stat-card">
                <div class="stat-value"><?= count($clients) ?></div>
                <div class="stat-label">Clients configurés</div>
            </div>
            <div class="stat-card">
                <div class="stat-value"><?= count($connected) ?></div>
                <div class="stat-label">Clients connectés</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">10.8.0.0/24</div>
                <div class="stat-label">Réseau VPN</div>
            </div>
        </div>
        
        <div class="card">
            <h2>➕ Ajouter un client</h2>
            <form method="POST">
                <input type="hidden" name="action" value="add_client">
                <div class="form-group">
                    <label for="client_name">Nom du client</label>
                    <input type="text" id="client_name" name="client_name" 
                           placeholder="bertrand, laptop-pro, iphone-13..." 
                           pattern="[a-zA-Z0-9_-]+" 
                           title="Lettres, chiffres, tirets et underscores uniquement"
                           required>
                </div>
                <button type="submit" class="btn">Créer le client</button>
            </form>
        </div>
        
        <div class="card">
            <h2>👥 Clients VPN</h2>
            <?php if (empty($clients)): ?>
                <p style="color: #718096;">Aucun client configuré pour le moment.</p>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Nom</th>
                            <th>IP VPN</th>
                            <th>Statut</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($clients as $client): ?>
                            <tr>
                                <td><strong><?= htmlspecialchars($client['name']) ?></strong></td>
                                <td><?= htmlspecialchars($client['ip']) ?></td>
                                <td>
                                    <?php if (isset($connected[$client['pubkey']])): ?>
                                        <span class="badge badge-success">● Connecté</span>
                                    <?php else: ?>
                                        <span class="badge badge-secondary">○ Hors ligne</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="actions">
                                        <a href="download.php?client=<?= urlencode($client['name']) ?>" class="btn btn-secondary">📥 Config</a>
                                        <a href="qrcode.php?client=<?= urlencode($client['name']) ?>" class="btn btn-secondary" target="_blank">📱 QR</a>
                                        <form method="POST" style="display: inline;" onsubmit="return confirm('Supprimer ce client ?');">
                                            <input type="hidden" name="action" value="remove_client">
                                            <input type="hidden" name="client_name" value="<?= htmlspecialchars($client['name']) ?>">
                                            <button type="submit" class="btn btn-danger">🗑️</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
