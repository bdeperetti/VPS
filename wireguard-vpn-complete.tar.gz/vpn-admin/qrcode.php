<?php
session_start();

if (!isset($_SESSION['authenticated'])) {
    header('Location: index.php');
    exit;
}

$clientName = $_GET['client'] ?? '';
$clientName = preg_replace('/[^a-zA-Z0-9_-]/', '', $clientName);

if (empty($clientName)) {
    die('Nom de client invalide');
}

$configFile = "/etc/wireguard/clients/{$clientName}.conf";

if (!file_exists($configFile)) {
    die('Configuration introuvable');
}

// Générer le QR code en PNG
exec("qrencode -t PNG -o /tmp/qr_{$clientName}.png < " . escapeshellarg($configFile));

$qrFile = "/tmp/qr_{$clientName}.png";
if (!file_exists($qrFile)) {
    die('Erreur de génération du QR code');
}

$config = file_get_contents($configFile);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Code - <?= htmlspecialchars($clientName) ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem;
        }
        .container {
            background: white;
            padding: 2.5rem;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            max-width: 600px;
            text-align: center;
        }
        h1 {
            color: #667eea;
            margin-bottom: 0.5rem;
            font-size: 1.8rem;
        }
        .client-name {
            color: #666;
            margin-bottom: 2rem;
            font-size: 1.1rem;
            font-weight: 600;
        }
        .qr-box {
            background: #f7fafc;
            padding: 2rem;
            border-radius: 12px;
            margin-bottom: 2rem;
        }
        .qr-box img {
            max-width: 100%;
            height: auto;
        }
        .instructions {
            text-align: left;
            background: #f7fafc;
            padding: 1.5rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
        }
        .instructions h3 {
            color: #667eea;
            margin-bottom: 1rem;
            font-size: 1.1rem;
        }
        .instructions ol {
            margin-left: 1.5rem;
        }
        .instructions li {
            margin-bottom: 0.5rem;
            color: #4a5568;
        }
        .config-box {
            background: #2d3748;
            color: #68d391;
            padding: 1.5rem;
            border-radius: 8px;
            text-align: left;
            font-family: 'Courier New', monospace;
            font-size: 0.85rem;
            white-space: pre-wrap;
            word-break: break-all;
            margin-bottom: 1.5rem;
            max-height: 300px;
            overflow-y: auto;
        }
        .btn {
            display: inline-block;
            padding: 0.875rem 1.5rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 600;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4);
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>📱 QR Code WireGuard</h1>
        <div class="client-name"><?= htmlspecialchars($clientName) ?></div>
        
        <div class="qr-box">
            <img src="data:image/png;base64,<?= base64_encode(file_get_contents($qrFile)) ?>" alt="QR Code">
        </div>
        
        <div class="instructions">
            <h3>📲 Instructions pour mobile</h3>
            <ol>
                <li>Installez l'app <strong>WireGuard</strong> (iOS/Android)</li>
                <li>Appuyez sur <strong>+</strong> puis <strong>"Scanner le QR code"</strong></li>
                <li>Scannez le QR code ci-dessus</li>
                <li>Activez la connexion</li>
            </ol>
        </div>
        
        <details>
            <summary style="cursor: pointer; color: #667eea; font-weight: 600; margin-bottom: 1rem;">
                Voir la configuration texte
            </summary>
            <div class="config-box"><?= htmlspecialchars($config) ?></div>
        </details>
        
        <a href="index.php" class="btn">← Retour au dashboard</a>
    </div>
</body>
</html>
<?php
// Nettoyer le fichier temporaire
@unlink($qrFile);
?>
