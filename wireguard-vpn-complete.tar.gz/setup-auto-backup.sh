#!/bin/bash

# Installation de la sauvegarde automatique quotidienne
# Usage: bash setup-auto-backup.sh

echo "⏰ Configuration de la sauvegarde automatique WireGuard"
echo "========================================================"
echo ""

BACKUP_SCRIPT="/usr/local/bin/backup-vpn.sh"
CRON_SCHEDULE="0 3 * * *"  # Tous les jours à 3h du matin

# Vérifier si le script de sauvegarde existe
if [ ! -f "$BACKUP_SCRIPT" ]; then
    echo "❌ Le script backup-vpn.sh n'existe pas dans /usr/local/bin/"
    echo "   Veuillez d'abord copier le script :"
    echo "   cp backup-vpn.sh /usr/local/bin/"
    echo "   chmod +x /usr/local/bin/backup-vpn.sh"
    exit 1
fi

# Vérifier si une tâche cron existe déjà
if crontab -l 2>/dev/null | grep -q "backup-vpn.sh"; then
    echo "⚠️  Une tâche cron existe déjà pour backup-vpn.sh"
    echo ""
    echo "Tâche actuelle :"
    crontab -l | grep "backup-vpn.sh"
    echo ""
    read -p "Voulez-vous la remplacer ? (o/N) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Oo]$ ]]; then
        echo "❌ Installation annulée"
        exit 0
    fi
    # Supprimer l'ancienne tâche
    crontab -l | grep -v "backup-vpn.sh" | crontab -
fi

# Ajouter la nouvelle tâche cron
(crontab -l 2>/dev/null; echo "$CRON_SCHEDULE $BACKUP_SCRIPT > /var/log/vpn-backup.log 2>&1") | crontab -

if [ $? -eq 0 ]; then
    echo "✅ Sauvegarde automatique configurée avec succès !"
    echo ""
    echo "📊 Configuration :"
    echo "   • Script : $BACKUP_SCRIPT"
    echo "   • Planification : Tous les jours à 3h du matin"
    echo "   • Log : /var/log/vpn-backup.log"
    echo "   • Destination : /root/vpn-backups/"
    echo "   • Rétention : 10 sauvegardes"
    echo ""
    echo "🔍 Tâches cron actuelles :"
    crontab -l | grep -v "^#"
    echo ""
    echo "💡 Commandes utiles :"
    echo "   • Voir les logs : tail -f /var/log/vpn-backup.log"
    echo "   • Lancer manuellement : $BACKUP_SCRIPT"
    echo "   • Modifier l'heure : crontab -e"
    echo "   • Supprimer la tâche : crontab -e (puis supprimer la ligne)"
    echo ""
    echo "📅 Prochaine exécution : $(date -d '03:00 tomorrow' '+%Y-%m-%d %H:%M:%S')"
else
    echo "❌ Erreur lors de la configuration de cron"
    exit 1
fi
