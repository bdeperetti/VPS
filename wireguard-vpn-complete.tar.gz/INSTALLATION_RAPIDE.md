# 🚀 Installation rapide - WireGuard VPN

## ⚡ Installation en 5 minutes

### Étape 1 : Copier les fichiers sur votre VPS

```bash
# Depuis votre machine locale
scp -r /path/to/wireguard-vpn-complete/ root@137.74.12.199:/root/vpn-setup/
```

### Étape 2 : Se connecter et installer

```bash
# Connexion SSH
ssh root@137.74.12.199

# Aller dans le répertoire
cd /root/vpn-setup

# Lancer l'installation
bash deploy-vpn.sh
```

L'installation configure automatiquement :
- ✅ WireGuard VPN
- ✅ Firewall UFW avec règles sécurisées
- ✅ Interface web d'administration
- ✅ Scripts de gestion des clients
- ✅ Nginx avec PHP

### Étape 3 : Créer votre premier client

```bash
# Créer un client
add-vpn-client.sh bertrand

# Afficher la configuration
cat /etc/wireguard/clients/bertrand.conf
```

### Étape 4 : Se connecter au VPN

**Sur Windows/Mac/Linux :**
1. Télécharger WireGuard : https://www.wireguard.com/install/
2. Copier le contenu du fichier `bertrand.conf`
3. Importer dans WireGuard
4. Activer la connexion

**Sur mobile (iOS/Android) :**
1. Installer l'app WireGuard
2. Générer un QR code : `qrencode -t ansiutf8 < /etc/wireguard/clients/bertrand.conf`
3. Scanner le QR code
4. Activer la connexion

### Étape 5 : Accéder à l'interface admin

Une fois connecté au VPN :

```
http://10.8.0.1:8888
```

**Mot de passe par défaut :** `ChangeMe2024!`

⚠️ **CHANGEZ-LE IMMÉDIATEMENT** dans `/var/www/vpn-admin/index.php`

---

## 🎯 Ports sécurisés par défaut

Ces ports sont maintenant accessibles **UNIQUEMENT via VPN** :
- Port 5678 (n8n)
- Port 3000 (Open WebUI)
- Port 10000 (Webmin)
- Port 8080 (services internes)

Pour ajouter d'autres ports :
```bash
ufw allow from 10.8.0.0/24 to any port XXXX comment 'Mon service'
ufw reload
```

---

## 📊 Vérifier que tout fonctionne

```bash
# Lancer le script de test
bash test-vpn.sh
```

Vous devriez voir :
- ✅ WireGuard installé
- ✅ Service actif
- ✅ Interface wg0 présente
- ✅ Firewall configuré
- ✅ Nginx actif

---

## 🆘 Problème ?

### Le VPN ne démarre pas
```bash
journalctl -u wg-quick@wg0 -n 50
systemctl status wg-quick@wg0
```

### Impossible d'accéder à l'interface admin
```bash
# Vérifier que vous êtes connecté au VPN
ip a | grep wg0

# Vérifier Nginx
systemctl status nginx
```

### Un service n'est plus accessible
```bash
# Vérifier les règles firewall
ufw status | grep "10.8.0.0"
```

---

## 📚 Documentation complète

- `README.md` - Guide complet et détaillé
- `COMMANDES.md` - Aide-mémoire de toutes les commandes
- `INTERFACE_GUIDE.md` - Guide visuel de l'interface web
- `test-vpn.sh` - Script de diagnostic
- `backup-vpn.sh` - Script de sauvegarde

---

## 🔒 Sécurité importante

1. ✅ Changez le mot de passe admin
2. ✅ Créez un client par appareil (ne partagez pas les configs)
3. ✅ Supprimez les clients des appareils perdus
4. ✅ Surveillez les connexions régulièrement
5. ✅ Activez les sauvegardes automatiques

```bash
# Sauvegarde automatique quotidienne
cp backup-vpn.sh /usr/local/bin/
chmod +x /usr/local/bin/backup-vpn.sh
bash setup-auto-backup.sh
```

---

**Vous êtes maintenant protégé ! 🎉**

Vos services sensibles ne sont plus accessibles depuis Internet.
Seuls les clients VPN autorisés peuvent y accéder.
