# 🔐 VPN WireGuard avec Interface Admin Web

Solution complète pour sécuriser l'accès à vos services sur kair.fr (137.74.12.199) via un VPN WireGuard avec interface web d'administration.

## 📋 Vue d'ensemble

Cette solution permet de :
- ✅ Bloquer l'accès à vos services sensibles depuis Internet
- ✅ Autoriser l'accès UNIQUEMENT via le tunnel VPN chiffré
- ✅ Gérer facilement les clients VPN via une interface web
- ✅ Générer des QR codes pour configuration mobile instantanée
- ✅ Voir en temps réel qui est connecté

## 🚀 Installation

### 1. Copier les fichiers sur votre VPS

```bash
# Depuis votre machine locale, copier le script d'installation
scp /path/to/deploy-vpn.sh root@137.74.12.199:/root/
scp -r /path/to/vpn-admin root@137.74.12.199:/root/
```

### 2. Lancer l'installation

```bash
# Se connecter au VPS
ssh root@137.74.12.199

# Lancer l'installation
bash /root/deploy-vpn.sh
```

L'installation prend environ 2-3 minutes et configure :
- WireGuard (VPN)
- Firewall UFW (règles de sécurité)
- Nginx (serveur web)
- PHP (interface admin)
- Scripts de gestion

## 🎯 Configuration post-installation

### 1. Créer votre premier client VPN

```bash
add-vpn-client.sh bertrand
```

Cela génère :
- Une paire de clés (privée/publique)
- Un fichier de configuration `.conf`
- Une IP VPN (10.8.0.2)

### 2. Récupérer la configuration

```bash
# Voir la config
cat /etc/wireguard/clients/bertrand.conf

# Télécharger sur votre machine
scp root@137.74.12.199:/etc/wireguard/clients/bertrand.conf .
```

### 3. Installer WireGuard sur votre machine

**Windows/Mac/Linux :**
- Téléchargez depuis https://www.wireguard.com/install/
- Importez le fichier `bertrand.conf`
- Activez la connexion

**Mobile (iOS/Android) :**
- Installez l'app WireGuard
- Scannez le QR code (généré via l'interface web)
- Activez la connexion

### 4. Accéder à l'interface admin

Une fois connecté au VPN :
```
http://10.8.0.1:8888
```

**Mot de passe par défaut :** `ChangeMe2024!`

⚠️ **IMPORTANT : Changez immédiatement ce mot de passe !**

Éditez `/var/www/vpn-admin/index.php` :
```php
define('ADMIN_PASSWORD', password_hash('VotreNouveauMotDePasse', PASSWORD_DEFAULT));
```

## 🎨 Interface d'administration

L'interface web permet de :

### Dashboard
- 📊 Voir le nombre de clients configurés
- 👥 Voir qui est connecté en temps réel
- 📱 Générer des QR codes pour mobile
- 📥 Télécharger les fichiers de configuration
- ➕ Créer de nouveaux clients
- 🗑️ Supprimer des clients

### Fonctionnalités
- **Ajout de client** : Nom + génération automatique de clés
- **QR Code** : Scan direct depuis mobile
- **Téléchargement** : Fichier `.conf` pour ordinateur
- **Suppression** : Révocation immédiate de l'accès
- **Statut** : Indicateur visuel connecté/déconnecté

## 🔒 Sécurité

### Accès aux services

Par défaut, ces ports sont configurés pour être accessibles **UNIQUEMENT via VPN** :

- Port 5678 (n8n)
- Port 3000 (Open WebUI)
- Port 10000 (Webmin)
- Port 8080 (services internes)

### Modifier les ports protégés

Éditez le script `/root/deploy-vpn.sh` avant installation, section :

```bash
declare -a VPN_PORTS=(
    "5678:n8n"
    "3000:Open WebUI"
    "10000:Webmin"
    "8080:Services internes"
    "XXXX:Votre service"  # Ajoutez vos ports
)
```

Ou manuellement après installation :

```bash
# Autoriser un port uniquement via VPN
ufw allow from 10.8.0.0/24 to any port 9999 comment 'Mon service'

# Bloquer le port depuis Internet (si ouvert)
ufw delete allow 9999

# Recharger
ufw reload
```

### Règles firewall actuelles

```bash
# Voir toutes les règles
ufw status verbose

# Voir les règles WireGuard
ufw status | grep -E '10.8.0.0|51820'
```

## 🛠️ Commandes utiles

### Gestion des clients

```bash
# Créer un client
add-vpn-client.sh nom-client

# Supprimer un client
remove-vpn-client.sh nom-client

# Lister les clients
cat /etc/wireguard/wg0.conf | grep "# " | grep -v "^#"
```

### Monitoring

```bash
# Voir les clients connectés
wg show

# Détails complets
wg show wg0

# Statut du service
systemctl status wg-quick@wg0

# Logs en temps réel
journalctl -u wg-quick@wg0 -f
```

### Maintenance

```bash
# Redémarrer WireGuard
systemctl restart wg-quick@wg0

# Recharger la config sans déconnecter les clients
wg syncconf wg0 <(wg-quick strip wg0)

# Voir la config serveur
cat /etc/wireguard/wg0.conf
```

## 📱 Configuration client détaillée

### Windows/Mac/Linux

1. Téléchargez WireGuard : https://www.wireguard.com/install/
2. Ouvrez l'application
3. Cliquez "Import tunnel(s) from file"
4. Sélectionnez votre fichier `.conf`
5. Cliquez "Activate"

### Mobile (iOS/Android)

**Option 1 : QR Code (recommandé)**
1. Installez l'app WireGuard
2. Connectez-vous à l'interface admin (via un autre appareil déjà connecté)
3. Cliquez sur "📱 QR" pour votre client
4. Dans l'app mobile : + → "Scan QR code"
5. Activez la connexion

**Option 2 : Import manuel**
1. Transférez le fichier `.conf` sur votre téléphone
2. Dans l'app : + → "Create from file or archive"
3. Sélectionnez le fichier
4. Activez la connexion

## 🔍 Dépannage

### Le VPN ne démarre pas

```bash
# Vérifier les logs
journalctl -u wg-quick@wg0 -n 50

# Vérifier la config
wg-quick up wg0

# Tester la connectivité
ping 10.8.0.1
```

### Impossible de se connecter à l'interface admin

```bash
# Vérifier que vous êtes bien connecté au VPN
ip a | grep wg0

# Vérifier que Nginx tourne
systemctl status nginx

# Vérifier les logs Nginx
tail -f /var/log/nginx/error.log
```

### Le firewall bloque un service

```bash
# Autoriser temporairement depuis Internet (debug uniquement)
ufw allow 5678

# Ré-autoriser uniquement via VPN
ufw delete allow 5678
ufw allow from 10.8.0.0/24 to any port 5678
ufw reload
```

### Un client ne peut pas se connecter

```bash
# Vérifier que le client est dans la config
grep "nom-client" /etc/wireguard/wg0.conf

# Recharger la config
wg syncconf wg0 <(wg-quick strip wg0)

# Vérifier les connexions actives
wg show wg0
```

## 📊 Architecture réseau

```
Internet
   │
   ├─→ Port 51820/UDP (WireGuard) ✅ OUVERT
   │
   ├─→ Ports 80, 443, 22 (services publics) ✅ OUVERTS
   │
   └─→ Ports 5678, 3000, 10000... ❌ BLOQUÉS
          │
          │  Via tunnel VPN chiffré ✅
          │
       10.8.0.0/24 (réseau VPN)
          │
          ├─→ 10.8.0.1 (serveur VPS)
          ├─→ 10.8.0.2 (client 1)
          ├─→ 10.8.0.3 (client 2)
          └─→ ...
```

## 🎯 Scénarios d'utilisation

### Accéder à n8n depuis l'extérieur

1. Connectez-vous au VPN
2. Ouvrez `http://137.74.12.199:5678` ou `http://10.8.0.1:5678`
3. ✅ Accès autorisé (via VPN)

Sans VPN : ❌ Connection refused

### Gérer plusieurs appareils

```bash
# Laptop pro
add-vpn-client.sh laptop-pro

# Laptop perso
add-vpn-client.sh laptop-perso

# iPhone
add-vpn-client.sh iphone

# iPad
add-vpn-client.sh ipad
```

Chaque appareil aura sa propre IP (10.8.0.2, 10.8.0.3, etc.)

### Révoquer un accès (ex: appareil perdu)

```bash
remove-vpn-client.sh iphone
```

L'appareil ne pourra plus se connecter immédiatement.

## 📦 Fichiers et répertoires

```
/etc/wireguard/
├── wg0.conf              # Config serveur WireGuard
├── server_private.key    # Clé privée serveur
├── server_public.key     # Clé publique serveur
└── clients/              # Configs clients
    ├── bertrand.conf
    ├── bertrand_private.key
    ├── bertrand_public.key
    └── ...

/var/www/vpn-admin/       # Interface web
├── index.php             # Dashboard
├── download.php          # Téléchargement configs
└── qrcode.php            # Génération QR codes

/usr/local/bin/
├── add-vpn-client.sh     # Script ajout client
└── remove-vpn-client.sh  # Script suppression client
```

## 🔐 Bonnes pratiques

1. **Changez le mot de passe admin** immédiatement après installation
2. **Utilisez des noms de clients explicites** : laptop-bertrand, iphone-bertrand
3. **Supprimez les clients inutilisés** pour limiter les points d'accès
4. **Surveillez régulièrement** les connexions actives (`wg show`)
5. **Sauvegardez** les configs clients dans un gestionnaire de mots de passe
6. **Documentez** les appareils autorisés

## 🆘 Support

En cas de problème :

1. Consultez les logs : `journalctl -u wg-quick@wg0 -n 100`
2. Vérifiez le firewall : `ufw status verbose`
3. Testez la connectivité : `ping 10.8.0.1` (depuis un client VPN)
4. Vérifiez les services : `systemctl status wg-quick@wg0 nginx`

## 📝 Notes

- Le réseau VPN est `10.8.0.0/24`
- Le serveur VPS a l'IP VPN `10.8.0.1`
- Les clients obtiennent des IP de `10.8.0.2` à `10.8.0.254`
- Le port WireGuard est `51820/UDP`
- L'interface admin est sur le port `8888`
- Le DNS par défaut est `1.1.1.1` (Cloudflare)

## 🔄 Mise à jour

Pour mettre à jour l'interface admin :

```bash
cd /var/www/vpn-admin
# Faire vos modifications
chown -R www-data:www-data /var/www/vpn-admin
systemctl reload nginx
```

---

**Fait avec ❤️ pour kair.fr**
