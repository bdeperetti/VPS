# 📝 Aide-mémoire WireGuard VPN - Commandes essentielles

## 🚀 Installation

```bash
# 1. Copier les fichiers sur le VPS
scp -r vpn-admin/ root@137.74.12.199:/root/
scp deploy-vpn.sh root@137.74.12.199:/root/

# 2. Se connecter au VPS
ssh root@137.74.12.199

# 3. Lancer l'installation
bash /root/deploy-vpn.sh
```

## 👥 Gestion des clients

### Créer un client
```bash
add-vpn-client.sh bertrand
add-vpn-client.sh laptop-pro
add-vpn-client.sh iphone-13
```

### Supprimer un client
```bash
remove-vpn-client.sh bertrand
```

### Lister les clients
```bash
# Voir tous les clients configurés
cat /etc/wireguard/wg0.conf | grep "^# " | grep -v "^#"

# Voir les configurations
ls -lh /etc/wireguard/clients/
```

### Récupérer une configuration
```bash
# Afficher la config
cat /etc/wireguard/clients/bertrand.conf

# Télécharger depuis votre machine locale
scp root@137.74.12.199:/etc/wireguard/clients/bertrand.conf .

# Générer un QR code
qrencode -t ansiutf8 < /etc/wireguard/clients/bertrand.conf
```

## 📊 Monitoring

### Voir les connexions actives
```bash
# Vue simple
wg show

# Vue détaillée
wg show wg0

# Voir uniquement les peers
wg show wg0 peers

# Voir avec statistiques de trafic
wg show wg0 transfer
```

### Logs en temps réel
```bash
# Logs WireGuard
journalctl -u wg-quick@wg0 -f

# Derniers 50 logs
journalctl -u wg-quick@wg0 -n 50

# Logs depuis une date
journalctl -u wg-quick@wg0 --since "2024-03-01"
```

### Statut du service
```bash
# Vérifier le statut
systemctl status wg-quick@wg0

# Voir si actif
systemctl is-active wg-quick@wg0

# Voir si activé au démarrage
systemctl is-enabled wg-quick@wg0
```

## 🔧 Maintenance

### Redémarrer WireGuard
```bash
systemctl restart wg-quick@wg0
```

### Recharger la configuration (sans couper les clients)
```bash
wg syncconf wg0 <(wg-quick strip wg0)
```

### Arrêter/Démarrer
```bash
systemctl stop wg-quick@wg0
systemctl start wg-quick@wg0
```

### Désactiver au démarrage
```bash
systemctl disable wg-quick@wg0
```

### Activer au démarrage
```bash
systemctl enable wg-quick@wg0
```

## 🔥 Firewall

### Voir les règles
```bash
# Toutes les règles
ufw status verbose

# Règles numérotées (pour supprimer)
ufw status numbered

# Règles VPN spécifiques
ufw status | grep "10.8.0.0"
```

### Ajouter un port accessible via VPN
```bash
ufw allow from 10.8.0.0/24 to any port 9999 comment 'Mon nouveau service'
ufw reload
```

### Supprimer une règle
```bash
# Par numéro (voir avec ufw status numbered)
ufw delete 5

# Par règle
ufw delete allow from 10.8.0.0/24 to any port 9999
```

### Bloquer un port depuis Internet
```bash
# Si le port est ouvert
ufw delete allow 5678

# Le port reste accessible via VPN si la règle existe
ufw status | grep 5678
```

## 🌐 Interface web admin

### Accéder à l'interface
```bash
# URL (uniquement via VPN)
http://10.8.0.1:8888

# Ou avec nom de domaine si configuré
https://vpn.kair.fr
```

### Vérifier Nginx
```bash
# Statut
systemctl status nginx

# Tester la config
nginx -t

# Recharger
systemctl reload nginx

# Logs
tail -f /var/log/nginx/error.log
tail -f /var/log/nginx/access.log
```

### Changer le mot de passe admin
```bash
# Éditer le fichier
nano /var/www/vpn-admin/index.php

# Trouver la ligne :
# define('ADMIN_PASSWORD', password_hash('ChangeMe2024!', PASSWORD_DEFAULT));

# Remplacer par votre mot de passe
# define('ADMIN_PASSWORD', password_hash('MonNouveauMotDePasse', PASSWORD_DEFAULT));
```

## 💾 Sauvegardes

### Sauvegarde manuelle
```bash
# Sauvegarde complète
bash /usr/local/bin/backup-vpn.sh

# Sauvegarde dans un répertoire spécifique
bash /usr/local/bin/backup-vpn.sh /backup/vpn/
```

### Configurer la sauvegarde automatique
```bash
# Installer la sauvegarde quotidienne à 3h
cp backup-vpn.sh /usr/local/bin/
chmod +x /usr/local/bin/backup-vpn.sh
bash setup-auto-backup.sh
```

### Voir les sauvegardes
```bash
ls -lh /root/vpn-backups/
```

### Restaurer une sauvegarde
```bash
# Arrêter les services
systemctl stop wg-quick@wg0
systemctl stop nginx

# Restaurer
tar -xzf /root/vpn-backups/wireguard_backup_20240330_030000.tar.gz -C /

# Redémarrer
systemctl start wg-quick@wg0
systemctl start nginx
```

## 🔍 Diagnostic

### Script de test complet
```bash
bash /root/test-vpn.sh
```

### Tests manuels
```bash
# Vérifier l'interface réseau
ip a show wg0

# Vérifier l'IP forwarding
cat /proc/sys/net/ipv4/ip_forward

# Vérifier les routes
ip route | grep wg0

# Test ping depuis le serveur vers le réseau VPN
ping -c 3 10.8.0.2

# Vérifier les ports ouverts
ss -tulpn | grep 51820
```

### Résolution de problèmes

**Problème : Service ne démarre pas**
```bash
journalctl -u wg-quick@wg0 -n 50
wg-quick up wg0  # Mode debug
```

**Problème : Clients ne peuvent pas se connecter**
```bash
# Vérifier le firewall
ufw status | grep 51820

# Vérifier que le port est ouvert
nc -zvu 137.74.12.199 51820
```

**Problème : Connecté mais pas d'accès aux services**
```bash
# Vérifier les règles firewall VPN
ufw status | grep "10.8.0.0"

# Vérifier l'IP forwarding
sysctl net.ipv4.ip_forward

# Vérifier iptables
iptables -t nat -L POSTROUTING -n
```

## 📋 Configuration

### Voir la configuration serveur
```bash
cat /etc/wireguard/wg0.conf
```

### Éditer la configuration
```bash
nano /etc/wireguard/wg0.conf

# Puis recharger
wg syncconf wg0 <(wg-quick strip wg0)
```

### Voir les clés
```bash
# Clé publique du serveur
cat /etc/wireguard/server_public.key

# Clé privée (sensible !)
cat /etc/wireguard/server_private.key
```

### IP publique du serveur
```bash
curl ifconfig.me
```

## 🎯 Scénarios courants

### Ajouter un nouvel utilisateur
```bash
# 1. Créer le client
add-vpn-client.sh nouveau-user

# 2. Récupérer la config
cat /etc/wireguard/clients/nouveau-user.conf

# 3. Ou générer un QR code
qrencode -t ansiutf8 < /etc/wireguard/clients/nouveau-user.conf
```

### Révoquer l'accès d'un appareil perdu
```bash
# Suppression immédiate
remove-vpn-client.sh appareil-perdu

# Vérification
wg show wg0 | grep -A 5 "peer:"
```

### Changer le port WireGuard
```bash
# 1. Éditer la config
nano /etc/wireguard/wg0.conf
# Modifier : ListenPort = 51820

# 2. Mettre à jour le firewall
ufw delete allow 51820/udp
ufw allow NOUVEAU_PORT/udp

# 3. Redémarrer
systemctl restart wg-quick@wg0

# 4. Mettre à jour les configs clients !
```

## 📚 Fichiers importants

```
/etc/wireguard/
├── wg0.conf                    # Config serveur
├── server_private.key          # Clé privée (SENSIBLE)
├── server_public.key           # Clé publique
└── clients/                    # Configs clients
    ├── bertrand.conf
    ├── bertrand_private.key
    └── bertrand_public.key

/var/www/vpn-admin/             # Interface web
├── index.php
├── download.php
└── qrcode.php

/usr/local/bin/
├── add-vpn-client.sh           # Script ajout
├── remove-vpn-client.sh        # Script suppression
└── backup-vpn.sh               # Script sauvegarde

/var/log/
├── wireguard.log               # Logs WireGuard
└── nginx/                      # Logs Nginx
```

## 🚨 Sécurité

### Permissions critiques
```bash
# Vérifier les permissions
ls -la /etc/wireguard/
# Les fichiers .key doivent être 600 (rw-------)

# Corriger si nécessaire
chmod 600 /etc/wireguard/*.key
chmod 600 /etc/wireguard/clients/*.key
```

### Audit de sécurité rapide
```bash
# Vérifier qui peut accéder aux clés
find /etc/wireguard -type f -name "*.key" -ls

# Vérifier les règles firewall
ufw status verbose

# Vérifier les connexions actives
wg show wg0
```

## 📞 Support rapide

```bash
# Voir toutes les infos essentielles
echo "=== WireGuard Status ==="
systemctl status wg-quick@wg0
echo ""
echo "=== Connected Clients ==="
wg show wg0
echo ""
echo "=== Firewall Rules ==="
ufw status | grep -E "10.8.0.0|51820"
echo ""
echo "=== Configured Clients ==="
cat /etc/wireguard/wg0.conf | grep "^# " | grep -v "^#"
```

---

**Conservez ce fichier pour référence rapide !**
