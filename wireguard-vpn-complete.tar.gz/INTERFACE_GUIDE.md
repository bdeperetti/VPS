# 🎨 Guide visuel de l'interface VPN Admin

## 📱 Page de connexion

```
╔════════════════════════════════════════════╗
║                                            ║
║    🔒 VPN Admin                            ║
║    Gestion WireGuard - kair.fr             ║
║                                            ║
║    ┌────────────────────────────────────┐ ║
║    │ Mot de passe admin                 │ ║
║    └────────────────────────────────────┘ ║
║                                            ║
║    ┌────────────────────────────────────┐ ║
║    │     Se connecter                   │ ║
║    └────────────────────────────────────┘ ║
║                                            ║
╚════════════════════════════════════════════╝
```

## 🏠 Dashboard principal

```
╔════════════════════════════════════════════════════════════════════╗
║ 🔐 VPN Admin - WireGuard              [Déconnexion]                ║
╠════════════════════════════════════════════════════════════════════╣
║                                                                     ║
║  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐  ║
║  │     5       │  │     3       │  │     10.8.0.0/24         │  ║
║  │  Clients    │  │  Clients    │  │     Réseau VPN          │  ║
║  │  configurés │  │  connectés  │  │                         │  ║
║  └─────────────┘  └─────────────┘  └─────────────────────────┘  ║
║                                                                     ║
║  ╔══════════════════════════════════════════════════════════════╗ ║
║  ║ ➕ Ajouter un client                                         ║ ║
║  ╠══════════════════════════════════════════════════════════════╣ ║
║  ║                                                              ║ ║
║  ║  Nom du client                                              ║ ║
║  ║  ┌──────────────────────────────────────────────────────┐  ║ ║
║  ║  │ bertrand, laptop-pro, iphone-13...                   │  ║ ║
║  ║  └──────────────────────────────────────────────────────┘  ║ ║
║  ║                                                              ║ ║
║  ║  [Créer le client]                                          ║ ║
║  ║                                                              ║ ║
║  ╚══════════════════════════════════════════════════════════════╝ ║
║                                                                     ║
║  ╔══════════════════════════════════════════════════════════════╗ ║
║  ║ 👥 Clients VPN                                               ║ ║
║  ╠══════════════════════════════════════════════════════════════╣ ║
║  ║                                                              ║ ║
║  ║  Nom          │ IP VPN      │ Statut      │ Actions        ║ ║
║  ║  ─────────────┼─────────────┼─────────────┼────────────── ║ ║
║  ║  bertrand     │ 10.8.0.2    │ ● Connecté  │ [📥][📱][🗑️]  ║ ║
║  ║  laptop-pro   │ 10.8.0.3    │ ○ Hors ligne│ [📥][📱][🗑️]  ║ ║
║  ║  iphone-13    │ 10.8.0.4    │ ● Connecté  │ [📥][📱][🗑️]  ║ ║
║  ║  ipad-air     │ 10.8.0.5    │ ○ Hors ligne│ [📥][📱][🗑️]  ║ ║
║  ║  laptop-perso │ 10.8.0.6    │ ● Connecté  │ [📥][📱][🗑️]  ║ ║
║  ║                                                              ║ ║
║  ╚══════════════════════════════════════════════════════════════╝ ║
║                                                                     ║
╚════════════════════════════════════════════════════════════════════╝
```

## 📱 Page QR Code

```
╔════════════════════════════════════════════════════════════╗
║                                                             ║
║    📱 QR Code WireGuard                                     ║
║    bertrand                                                 ║
║                                                             ║
║    ┌─────────────────────────────────────────────────┐    ║
║    │                                                   │    ║
║    │   ████ ██  ████ ████  ██  ████ ████ ████        │    ║
║    │   ██ ██  ██ ██ ██  ██ ██ ██ ██    ██ ██         │    ║
║    │   ██    ████ ████   ████  ████   ██  ████        │    ║
║    │   ██    ██ ████  ████  ████  ██   ██  ██         │    ║
║    │   ████ ██    ██ ██ ████  ████ ████ ██ ████       │    ║
║    │                                                   │    ║
║    │        [QR Code pour mobile]                     │    ║
║    │                                                   │    ║
║    └─────────────────────────────────────────────────┘    ║
║                                                             ║
║    ╔═══════════════════════════════════════════════════╗  ║
║    ║ 📲 Instructions pour mobile                       ║  ║
║    ╠═══════════════════════════════════════════════════╣  ║
║    ║ 1. Installez l'app WireGuard (iOS/Android)       ║  ║
║    ║ 2. Appuyez sur + puis "Scanner le QR code"       ║  ║
║    ║ 3. Scannez le QR code ci-dessus                  ║  ║
║    ║ 4. Activez la connexion                          ║  ║
║    ╚═══════════════════════════════════════════════════╝  ║
║                                                             ║
║    ▼ Voir la configuration texte                           ║
║                                                             ║
║    [← Retour au dashboard]                                 ║
║                                                             ║
╚════════════════════════════════════════════════════════════╝
```

## 🎯 Actions disponibles

### Bouton [📥 Config]
- Télécharge le fichier `.conf` pour Windows/Mac/Linux
- Fichier prêt à importer dans l'application WireGuard

### Bouton [📱 QR]
- Ouvre une nouvelle page avec le QR code
- Permet la configuration instantanée sur mobile
- Contient aussi la config texte en bas de page

### Bouton [🗑️]
- Supprime le client après confirmation
- Révoque immédiatement l'accès VPN
- Supprime tous les fichiers associés

## 📊 États des clients

### ● Connecté (vert)
```
● Connecté
```
Le client est actuellement connecté au VPN

### ○ Hors ligne (gris)
```
○ Hors ligne
```
Le client est configuré mais pas connecté

## 🔔 Messages système

### Succès
```
╔════════════════════════════════════════════════════════════╗
║ ✓ Client bertrand créé avec succès                         ║
╚════════════════════════════════════════════════════════════╝
```

### Erreur
```
╔════════════════════════════════════════════════════════════╗
║ ✗ Erreur : Le client bertrand existe déjà                  ║
╚════════════════════════════════════════════════════════════╝
```

## 🎨 Design moderne

L'interface utilise :
- **Gradient violet** : #667eea → #764ba2
- **Police système** : -apple-system, BlinkMacSystemFont, Segoe UI
- **Cards blanches** avec ombres subtiles
- **Animations** au survol des boutons
- **Responsive** : s'adapte aux mobiles et tablettes
- **Badge colorés** pour les statuts

## 📱 Responsive mobile

Sur mobile, l'interface s'adapte :
- Colonnes qui se replient en une seule colonne
- Statistiques qui passent en grille verticale
- Boutons d'action qui s'empilent
- Menu burger pour la navigation

## 🔒 Sécurité de l'interface

- Authentification par mot de passe hashé (bcrypt)
- Session PHP sécurisée
- Protection contre injections SQL (aucune DB)
- Validation des noms de clients (regex strict)
- Accessible UNIQUEMENT via VPN (règle Nginx)
- Timeout de session après inactivité

## 💡 Conseils d'utilisation

1. **Nommage des clients** : Utilisez un format clair
   - ✅ `bertrand-laptop`, `iphone-bertrand`, `ipad-maylis`
   - ❌ `client1`, `test`, `tmp`

2. **Gestion des appareils** : Créez un client par appareil
   - Ne partagez jamais une même config entre appareils
   - Supprimez les clients des appareils perdus/volés

3. **Monitoring** : Consultez régulièrement le dashboard
   - Vérifiez qui est connecté
   - Détectez les connexions anormales
   - Supprimez les clients inutilisés

4. **Sécurité** : Changez le mot de passe admin
   - Ne laissez pas le mot de passe par défaut
   - Utilisez un mot de passe fort
   - Ne le partagez avec personne

## 🎯 Workflow typique

### Ajouter un nouvel appareil

1. Se connecter à l'interface admin (via VPN)
2. Cliquer sur "Ajouter un client"
3. Entrer un nom explicite (ex: `iphone-bertrand`)
4. Cliquer sur "Créer le client"
5. Pour PC : cliquer sur [📥 Config] et télécharger
6. Pour mobile : cliquer sur [📱 QR] et scanner
7. Activer la connexion sur l'appareil
8. Retourner au dashboard pour vérifier la connexion (● Connecté)

### Révoquer un appareil perdu

1. Se connecter à l'interface admin
2. Trouver le client dans la liste
3. Cliquer sur [🗑️]
4. Confirmer la suppression
5. L'appareil ne peut plus se reconnecter

### Vérifier qui est connecté

1. Se connecter à l'interface admin
2. Regarder les badges de statut dans la liste
3. Les clients avec ● sont actuellement connectés
4. Les clients avec ○ sont hors ligne

---

**Interface créée pour simplifier la gestion de votre VPN WireGuard !**
